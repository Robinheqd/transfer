// List of words for the game
const words = [
    'hangman', 'javascript', 'computer', 'programming', 'algorithm',
    'internet', 'keyboard', 'monitor', 'developer', 'application',
    'interface', 'database', 'network', 'server', 'security',
    'software', 'hardware', 'mobile', 'website', 'browser',
    'function', 'variable', 'loop', 'conditional', 'array',
    'object', 'class', 'method', 'parameter', 'argument'
];

// Initialize global variables
let selectedWord = '';
let guessedLetters = [];
let incorrectGuesses = 0;
let hintUsed = false;
let hintsRemaining = 1; // Initial number of hints
const timeLimit = 60; // 60 seconds
let timer;
let score = 0;
const pointsPerLetter = 10;
const pointsForWord = 100;
const pointsPerIncorrectGuess = 20;

// Function to start the timer
function startTimer() {
    let timeRemaining = timeLimit;
    timer = setInterval(function() {
        timeRemaining--;
        document.getElementById('timer').innerText = 'Time remaining: ' + timeRemaining + 's';
        if (timeRemaining === 0) {
            clearInterval(timer);
            document.getElementById('message').innerText = 'Time\'s up! You lose! The word was: ' + selectedWord;
            document.getElementById('guesses').style.display = 'none';
        }
    }, 1000);
}

// Function to stop the timer
function stopTimer() {
    clearInterval(timer);
}

// Function to update the score
function updateScore() {
    let scoreDisplay = 'Score: ' + score;
    document.getElementById('score').innerText = scoreDisplay;
}

// Function to handle correct letter guess
function handleCorrectGuess() {
    score += pointsPerLetter;
    updateScore();
}

// Function to handle correct word guess
function handleCorrectWord() {
    score += pointsForWord;
    updateScore();
}

// Function to handle incorrect guess
function handleIncorrectGuess() {
    score -= pointsPerIncorrectGuess;
    updateScore();
}

// Function to start or restart the game
function startGame() {
    // Randomly select a word from the list
    selectedWord = words[Math.floor(Math.random() * words.length)];

    // Reset guessed letters, incorrect guesses, hint status, hints remaining, and score
    guessedLetters = [];
    incorrectGuesses = 0;
    hintUsed = false;
    hintsRemaining = 1;
    score = 0;
    updateScore();

    // Clear hangman display
    document.getElementById('hangman').innerHTML = '';

    // Display word with underscores
    displayWord();

    // Clear game status message
    document.getElementById('message').innerText = '';

    // Show guesses input and button
    document.getElementById('guesses').style.display = 'block';

    // Reset hint counter
    document.getElementById('hint-count').innerText = hintsRemaining;

    // Start the timer
    startTimer();
}

// Function to display the word with guessed letters
function displayWord() {
    let wordDisplay = '';
    for (let char of selectedWord) {
        if (guessedLetters.includes(char)) {
            wordDisplay += char + ' ';
        } else {
            wordDisplay += '_ ';
        }
    }
    document.getElementById('word-container').innerText = wordDisplay;
}

// Function to handle letter guessing
function guessLetter() {
    let letterInput = document.getElementById('letter-input').value.toLowerCase();
    if (letterInput && /^[a-zA-Z]$/.test(letterInput)) {
        if (!guessedLetters.includes(letterInput)) {
            guessedLetters.push(letterInput);
            if (!selectedWord.includes(letterInput)) {
                incorrectGuesses++;
                handleIncorrectGuess();
                // Update hangman display
                updateHangman();
            } else {
                handleCorrectGuess();
            }
            displayWord();
            checkGameStatus();
        } else {
            alert('You already guessed this letter!');
        }
    } else {
        alert('Please enter a valid single letter!');
    }
}

// Function to update hangman display
function updateHangman() {
    let hangmanImage = '';
    if (incorrectGuesses === 1) {
        hangmanImage = '<img src="hangman1.png" alt="Hangman Step 1">';
    } else if (incorrectGuesses === 2) {
        hangmanImage = '<img src="hangman2.png" alt="Hangman Step 2">';
    } else if (incorrectGuesses === 3) {
        hangmanImage = '<img src="hangman3.png" alt="Hangman Step 3">';
    } else if (incorrectGuesses === 4) {
        hangmanImage = '<img src="hangman4.png" alt="Hangman Step 4">';
    } else if (incorrectGuesses === 5) {
        hangmanImage = '<img src="hangman5.png" alt="Hangman Step 5">';
    } else if (incorrectGuesses === 6) {
        hangmanImage = '<img src="hangman6.png" alt="Hangman Step 6">';
    }
    document.getElementById('hangman').innerHTML = hangmanImage;
}

// Function to check game status (win/lose)
function checkGameStatus() {
    if (incorrectGuesses === 6) {
        document.getElementById('message').innerText = 'You lose! The word was: ' + selectedWord;
        document.getElementById('guesses').style.display = 'none';
    } else if (!document.getElementById('word-container').innerText.includes('_')) {
        handleCorrectWord();
        document.getElementById('message').innerText = 'Congratulations! You win!';
        document.getElementById('guesses').style.display = 'none';
    }
}

// Function to provide a hint
function giveHint() {
    if (!hintUsed && hintsRemaining > 0) {
        // Find a random letter from the selected word that hasn't been guessed yet
        let remainingLetters = selectedWord.split('').filter(letter => !guessedLetters.includes(letter));
        if (remainingLetters.length > 0) {
            let randomIndex = Math.floor(Math.random() * remainingLetters.length);
            let hintLetter = remainingLetters[randomIndex];
            // Add hint letter to guessed letters
            guessedLetters.push(hintLetter);
            // Display word with updated guessed letters
            displayWord();
            // Mark hint as used
            hintUsed = true;
            // Decrease hint count
            hintsRemaining--;
            document.getElementById('hint-count').innerText = hintsRemaining;
            // Disable hint button if no hints remaining
            if (hintsRemaining === 0) {
                document.getElementById('controls').getElementsByTagName('button')[1].disabled = true;
            }
        }
    } else {
        alert('No hints remaining!');
    }
}

// Function to restart the game
function restartGame() {
    // Stop the timer if it's running
    stopTimer();
    
    // Start a new game
    startGame();
}

// Initial function call to update the score
updateScore();
